import React from 'react'
import Faq from '../../components/Faqs'
import Bottomcustom from '../../components/Bottomcustom'

const Faqs = () => {
  return (
    <div>
        <Faq/>
        <Bottomcustom/>
    </div>
  )
}

export default Faqs