import React from 'react'

const Jobs = () => {
  return (
    <div>Jobs</div>
  )
}

export default Jobs