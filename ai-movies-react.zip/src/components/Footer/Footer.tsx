import { useTranslation } from "react-i18next";
import { FaFacebookF, FaLinkedinIn } from "react-icons/fa6";
import { BsSend } from "react-icons/bs";

const Footer = () => {
  const { t, i18n } = useTranslation();

  return (
    <div className="bg-[#0d1c5a] flex flex-col lg:px-[80px] px-[20px] max-w-[2000px] w-[100%]">
      <div className="flex h-fit">
        <img className="w-[200px] h-fit" src="/white.svg" alt="" />
      </div>
      <div className="flex md:flex-row justify-between gap-[30px] flex-col">
        <div className="flex flex-wrap gap-[60px]">
          <div className="flex flex-col gap-1">
            <div className="lg:text-sm text-xs font-[Outfit-Bold]  text-[white]">
              {t("footer.quickFind")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.caseStudies")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.aboutUs")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.contact")}
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <div className="lg:text-sm text-xs font-[Outfit-Bold]  text-[white]">
              {t("footer.legal")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.imprint")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.privacy")}
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <div className="lg:text-sm text-xs font-[Outfit-Bold]  text-[white]">
              {t("footer.additional")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.contact")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.faq")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.jobs")}
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <div className="lg:text-sm text-xs font-[Outfit-Bold]  text-[white]">
              {t("footer.social")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.news")}
            </div>
            <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-light200">
              {t("footer.blog")}
            </div>
            <div className="flex gap-[10px]">
              <div className="bg-white rounded-sm p-[4px]">
                <FaFacebookF className="text-[#0d1c5a] text-[18px]" />
              </div>
              <div className="bg-white rounded-sm p-[4px]">
                <FaLinkedinIn className="text-[#0d1c5a] text-[18px]" />
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <div className="lg:text-sm text-xs font-[Outfit-Bold]  text-[white]">
            {t("footer.dontMiss")}
          </div>
          <div className="lg:text-sm text-xs font-[Outfit-Regular]  text-[white]">
            {t("footer.subscribeNewsletter")}
          </div>
          <input
            className="text-sm text-white w-fit px-[20px] py-[10px] my-1 border-[3px] border-white rounded-md bg-transparent"
            placeholder={t("footer.emailPlaceholder")}
            type="text"
          />
          <div className=" text-xs font-[Outfit-Regular]  text-light200">
            {t("footer.subscriptionNote")}
          </div>
          <div className="lg:text-sm text-xs gap-2 font-[Outfit-Bold]  text-primary flex items-center px-[24px] py-[8px] bg-light200 rounded-md w-fit ">
            <BsSend />
            {t("footer.subscribeButton")}
          </div>
        </div>
      </div>
      <div>
        <select
          name=""
          id=""
          className="rounded-md px-[24px] py-[8px] font-[Outfit-Bold]"
          onChange={(e) => i18n.changeLanguage(e.target.value)}
        >
          <option value="en">{t("languages.english")}</option>
          <option value="fr">{t("languages.french")}</option>
          {/* Add more language options as needed */}
        </select>
      </div>
    </div>
  );
};

export default Footer;
