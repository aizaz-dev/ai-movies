import { Route, Routes } from "react-router-dom";
import Untersiete from "./pages/untersiete/Untersiete";
import Stellenbeschreibung from "./pages/stellenbeschreibung/Stellenbeschreibung";
import Header from "./components/header/Header";
import Footer from "./components/Footer/Footer";
import Jobs from "./pages/jobs/Jobs";
import Faq from "./pages/faq/Faq";
import Uber from "./pages/Uber/Uber";
import Case from "./pages/case/Case";

function App() {
  return (
    <>
      <Header />
      <Routes>
        {/* page */}
        <Route path="/" element={<Untersiete />} />
        {/* page 3 */}
        <Route path="/uber" element={<Uber />} />
        {/* page 4 */}
        <Route path="/case" element={<Case />} />
         {/* Page 7 */}
         <Route path="/faqs" element={<Faq />} />
         {/* Page 8 */}
        <Route path="/jobs" element={<Jobs />} />
        {/* Page 10*/}
        <Route path="/stellenbeschreibung" element={<Stellenbeschreibung />} />
        
       

      </Routes>
      <Footer />
    </>
  );
}

export default App;
